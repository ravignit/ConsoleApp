﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CricketPOS
{
    public class Product
    {
        //[Required]
        public string ID { get; set; }
        public string PDate { get; set; }
        public string UserName { get; set; }
        public string ItemName { get; set; }
        public string ItemCost { get; set; }
        public string ItemQty { get; set; }
        public string TotalPrice { get; set; }
    }
    public class CricketKitHolsale
    {
        List<Product> MyList = new List<Product>();
        char createAnotherUser = 'N';
        /// <summary>
        /// Taking user input
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pdate"></param>
        /// <param name="username"></param>
        /// <returns></returns>
        public string UserInput(string pid,string pdate,string username)
        {
            return pid + pdate + username;
            //string update = pdate;
            //string uusername = username;
        }
        /// <summary>
        /// Calculate total price as per item and quantity
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pdate"></param>
        /// <param name="username"></param>
        /// <param name="itemname"></param>
        /// <param name="price"></param>
        /// <param name="qty"></param>
        public void TotalData(string pid, string pdate, string username, string itemname, string price, string qty)
        {
            //Note:- removing do while for single product testing.
            //do
            //{
                double totalPrice;
                double itemcost, itemqty;
                itemcost = Convert.ToDouble(price);
                itemqty = Convert.ToDouble(qty);
                totalPrice = +itemcost * itemqty;
                String totalPriceString = Convert.ToString(totalPrice);
                MyList.Add(new Product { ID = pid, PDate = pdate, UserName = username, ItemName = itemname, ItemCost = price, ItemQty = qty, TotalPrice = totalPriceString });
                //Console.WriteLine("Do you want to enter another purchase details[Y/N]? : ");
                //createAnotherUser = char.ToUpper(Console.ReadKey(false).KeyChar);
            //} while (createAnotherUser == 'Y' || createAnotherUser == 'y');
        }
        /// <summary>
        /// Display total data by user Id with total price
        /// </summary>
        /// <returns></returns>
        public string Display()
        {
            Console.WriteLine("Purchase Details Are:-");
            //Console.WriteLine("---------------------------------------------------");
            foreach (var item in MyList)
                return item.ID+" "+item.UserName+" "+item.TotalPrice;
            return "";
            //Console.WriteLine("End of Program; Press Enter to Exit");
            //Console.ReadLine();
        }
        /// <summary>
        /// Main Method for program entery point
        /// </summary>
        public static void Main()
        {

            CricketKitHolsale sale = new CricketKitHolsale();
            string pid; string pdate; string username; string itemname; string price; string qty;
            pid = "1";
            pdate = "12/12/2021";
            username = "Kumar";
            itemname = "Ball";
            price = "200";
            qty = "5";

            //Calling total data for executing the program.

            sale.TotalData(pid, pdate, username, itemname, price, qty);
            //Displaying output of program
            Console.Write( sale.Display());


            ///Another program with do while loop

            //UserInput("","","");
            //List<Product> MyList = new List<Product>();
            //char createAnotherUser = 'N';
            //Console.WriteLine("Enter Purchase ID: ");
            //string pId = Console.ReadLine();
            //while (string.IsNullOrEmpty(pId))
            //{
            //    Console.WriteLine("ID can't be empty! Input ID once more");
            //    pId = Console.ReadLine();
            //}
            //Console.WriteLine("Enter Purchase Date: ");
            //string pdate = Console.ReadLine();
            //while (string.IsNullOrEmpty(pdate))
            //{
            //    Console.WriteLine("Date can't be empty! Input Date once more");
            //    pdate = Console.ReadLine();
            //}
            //Console.WriteLine("Enter User Name: ");
            //string name = Console.ReadLine();
            //while (string.IsNullOrEmpty(name))
            //{
            //    Console.WriteLine("Name can't be empty! Input Name once more");
            //    name = Console.ReadLine();
            //}

            //do
            //{
            //    Console.WriteLine("Enter Item Name: ");
            //    string itemname = Console.ReadLine();
            //    while (string.IsNullOrEmpty(itemname))
            //    {
            //        Console.WriteLine("Item Name can't be empty! Input Item Name once more");
            //        itemname = Console.ReadLine();
            //    }
            //    Console.WriteLine("Enter Item Price: ");
            //    string price = Console.ReadLine();
            //    while (string.IsNullOrEmpty(price))
            //    {
            //        Console.WriteLine("Item Price can't be empty! Input Item Price once more");
            //        price = Console.ReadLine();
            //    }
            //    Console.WriteLine("Enter Item Quentity");
            //    string qty = Console.ReadLine();
            //    while (string.IsNullOrEmpty(qty))
            //    {
            //        Console.WriteLine("Item Quentity can't be empty! Input Item Quentity once more");
            //        qty = Console.ReadLine();
            //    }
            //    double totalPrice;
            //    double itemcost, itemqty;
            //    itemcost = Convert.ToDouble(price);
            //    itemqty = Convert.ToDouble(qty);
            //    totalPrice = +itemcost * itemqty;
            //    String totalPriceString = Convert.ToString(totalPrice);
            //    MyList.Add(new Product { ID = pId, PDate = pdate, UserName = name, ItemName = itemname, ItemCost = price, ItemQty = qty, TotalPrice = totalPriceString });
            //    Console.WriteLine("Do you want to enter another purchase details[Y/N]? : ");
            //    createAnotherUser = char.ToUpper(Console.ReadKey(false).KeyChar);
            //} while (createAnotherUser == 'Y' || createAnotherUser == 'y');


        }
    }
}
