using Microsoft.VisualStudio.TestTools.UnitTesting;
using CricketPOS;
using System.IO;
using System;

namespace TestCricketPOS
{
    [TestClass]
    public class CricketPOSTest
    {
        /// <summary>
        /// To test total output value
        /// </summary>
        [TestMethod]
        public void TestMethod1()
        {
            //Arrange
            string expectedValue = "1 Kumar 1000";
            string pid; string pdate; string username; string itemname; string price; string qty;
            pid = "1";
            pdate = "12/12/2021";
            username = "Kumar";
            itemname = "Ball";
            price = "200";
            qty = "5";

           //Act
            CricketKitHolsale c1 = new CricketKitHolsale();
            c1.TotalData(pid, pdate, username, itemname, price, qty);
            //Assert
            string result = c1.Display();
            Assert.AreEqual(expectedValue, result);
        }
    }
}
